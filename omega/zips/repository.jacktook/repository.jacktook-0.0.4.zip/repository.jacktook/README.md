# Kodi Repository for [Jacktook](https://github.com/Sam-Max/plugin.video.jacktook)


## Installation (2 options)

1. Get the repository from [latest release](https://github.com/Sam-Max/repository.jacktook/releases/latest. 
Then, [install from zip](https://kodi.wiki/view/Add-on_manager#How_to_install_from_a_ZIP_file) within [Kodi](https://kodi.tv/).

2. Use the link: [sam-max.github.io](https://sam-max.github.io/packages)



